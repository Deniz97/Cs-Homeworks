#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "the2.h"


node *init(int branch){

}


int branch_factor(node *list){

}


int num_nodes(node *list){

}


void clear(node *list){

}


int is_empty(node *list){

}


int num_levels(node *list){

}


node *insert(node *list, int key, char *value){

}


int delete(node *list, int key){

}


node *find(node *list, int key){

}


void path(node *list, int key){
    
}


void print(node *list){

}


void print_level(node *list, int level){

}
